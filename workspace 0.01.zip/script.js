$(function () {
    $("#accordion").accordion({
        collapsible: true,
        heightStyle: "content"
    });
    $("#dialog").dialog({
        autoOpen: false,
        show: {
            effect: "blind",
            duration: 1000
        },
        hide: {
            effect: "explode",
            duration: 1000
        }
    });
    $("#dialogaccount").dialog({
        autoOpen: false,
    });
    $("#opener").on("click", function () {
        $("#dialog").dialog("open");
    });
    $("#acountinfo").on("click", function () {
        $("#dialogaccount").dialog("open");
    });
});

